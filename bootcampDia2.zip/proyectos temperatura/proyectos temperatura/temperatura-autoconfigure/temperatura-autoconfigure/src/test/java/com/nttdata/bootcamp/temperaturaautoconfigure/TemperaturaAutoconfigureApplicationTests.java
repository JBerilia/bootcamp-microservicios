package com.nttdata.bootcamp.temperaturaautoconfigure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TemperaturaAutoconfigureApplicationTests {

	@Test
	void contextLoads() {
	}

}
