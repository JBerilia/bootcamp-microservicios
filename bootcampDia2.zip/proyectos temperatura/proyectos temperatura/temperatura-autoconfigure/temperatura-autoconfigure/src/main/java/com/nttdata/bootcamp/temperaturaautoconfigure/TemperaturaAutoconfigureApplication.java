package com.nttdata.bootcamp.temperaturaautoconfigure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemperaturaAutoconfigureApplication {

	public static void main(String[] args) {
		SpringApplication.run(TemperaturaAutoconfigureApplication.class, args);
	}

}
