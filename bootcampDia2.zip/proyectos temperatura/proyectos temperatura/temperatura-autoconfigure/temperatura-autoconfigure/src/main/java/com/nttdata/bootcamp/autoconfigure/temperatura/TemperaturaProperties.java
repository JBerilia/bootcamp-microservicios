package com.nttdata.bootcamp.autoconfigure.temperatura;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("TemperaturaLibreriaApplication.grados")
@Getter
@Setter
public class TemperaturaProperties {
	
	private String grados = "Farenheit";

}
