package com.nttdata.bootcamp.temperaturastarter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemperaturaStarterApplication {

	public static void main(String[] args) {
		SpringApplication.run(TemperaturaStarterApplication.class, args);
	}

}
