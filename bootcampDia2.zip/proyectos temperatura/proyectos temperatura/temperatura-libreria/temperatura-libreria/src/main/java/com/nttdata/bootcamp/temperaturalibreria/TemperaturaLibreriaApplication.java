package com.nttdata.bootcamp.temperaturalibreria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

public class TemperaturaLibreriaApplication {
	private String grados;
	
	public TemperaturaLibreriaApplication(String grados) {
		this.grados = grados;
	}
	
	public String convertir(String grados) {
		Double temperatura = null;
		switch(grados) {
		case "Farenheit":
			temperatura = (temperatura*1.8d)+32;
			break;
		case "Celsius":
			temperatura = (temperatura -32)/1.8d;
			break;
		}
		return Double.toString(temperatura);
	}
	

		
}

